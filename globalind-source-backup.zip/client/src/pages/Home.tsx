import { useEffect, useState, type CSSProperties } from "react";
import { ArrowDown, ArrowRight, ArrowUpRight, Menu, X } from "lucide-react";
import { Link } from "wouter";
import BrandLogo from "../components/BrandLogo";
import { businesses } from "../data/businesses";

function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link href="/" className="home-brand" aria-label="Global India Group home"><BrandLogo compact /></Link>
        <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        <nav className={`main-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
          <Link href="/" className="nav-link" onClick={() => setMenuOpen(false)}>The group</Link>
          {businesses.map((business) => <Link key={business.slug} href={`/${business.slug}`} className="nav-link" onClick={() => setMenuOpen(false)}>{business.shortName}</Link>)}
          <a href="#businesses" className="nav-cta" onClick={() => setMenuOpen(false)}>Explore our businesses <ArrowUpRight size={15} /></a>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="site-footer">
      <div className="footer-main"><BrandLogo inverse compact /><p>Three specialist teams, connected by a bigger picture.</p><a href="https://globalindianagpur.com" target="_blank" rel="noreferrer">globalindianagpur.com <ArrowUpRight size={14} /></a></div>
      <div className="footer-bottom"><span>© {new Date().getFullYear()} Global India Group</span><span>People · Places · Possibilities</span></div>
    </footer>
  );
}

export default function Home() {
  useEffect(() => { document.title = "Global India Group | People, Places & Possibilities"; }, []);
  return (
    <div className="site-shell home-page">
      <Header />
      <main>
        <section className="home-hero section-wrap">
          <div className="home-hero-copy">
            <div className="eyebrow"><span className="eyebrow-line" /> A connected group of specialist businesses</div>
            <BrandLogo className="hero-group-mark" />
            <h1>Different strengths.<br /><em>One wider vision.</em></h1>
            <p className="hero-description">We bring together specialist businesses that help people, ideas and places move forward—across media, real estate and careers.</p>
            <a className="button button-dark" href="#businesses">Meet our businesses <ArrowDown size={16} /></a>
            <div className="hero-note"><span className="note-dot" /> Rooted in Nagpur. Connected to opportunity.</div>
          </div>
          <div className="home-hero-visual" aria-label="A glimpse of our connected businesses">
            <div className="visual-rings" aria-hidden="true" />
            <div className="hero-photo photo-main"><img src={businesses[0].heroImage} alt="A business founder speaking in a media studio" /><span>STORIES · VISIBILITY</span></div>
            <div className="hero-photo photo-small photo-property"><img src={businesses[1].heroImage} alt="A contemporary home surrounded by greenery" /><span>PLACES · VALUE</span></div>
            <div className="hero-photo photo-small photo-people"><img src={businesses[2].heroImage} alt="A candidate meeting with a recruiter" /><span>PEOPLE · POTENTIAL</span></div>
            <div className="visual-caption"><span className="caption-spark">✳</span><span>Three perspectives.<br /><b>One shared purpose.</b></span></div>
          </div>
        </section>

        <section className="group-intro section-wrap">
          <div className="section-kicker">A group built around connection</div>
          <div className="intro-copy"><h2>Expertise with a <em>human point of view.</em></h2><p>Every business has its own craft and character. Together, they create a broader platform for visibility, trusted spaces and meaningful work.</p></div>
          <div className="intro-signature"><BrandLogo compact /><span>Media · Property · Workforce</span></div>
        </section>

        <section id="businesses" className="businesses-section section-wrap">
          <div className="section-heading-row"><div><div className="section-kicker">The companies</div><h2>Find the right <em>specialist.</em></h2></div><p>Explore the business that fits what you’re working toward.</p></div>
          <div className="business-card-list">
            {businesses.map((business, index) => (
              <Link key={business.slug} href={`/${business.slug}`} className={`business-card business-card-${business.slug}`} style={{ "--brand": business.brand, "--brand-soft": business.soft } as CSSProperties}>
                <div className="business-card-top"><BrandLogo kind={business.logo} compact /><span className="card-index">0{index + 1}</span></div>
                <div className="business-card-image"><img src={business.heroImage} alt={business.heroAlt} loading="lazy" /><span className="card-arrow"><ArrowUpRight size={19} /></span></div>
                <div className="business-card-copy"><span className="business-descriptor">{business.descriptor}</span><h3>{business.name}</h3><p>{business.intro}</p><span className="text-link">Explore this business <ArrowRight size={15} /></span></div>
              </Link>
            ))}
          </div>
        </section>

        <section className="group-values section-wrap">
          <div className="values-heading"><span className="section-kicker">How we work</span><h2>Built on trust.<br /><em>Made for what’s next.</em></h2></div>
          <div className="values-body"><p>Good connections make progress possible. Across every conversation, property and career opportunity, we value clear communication, responsible guidance and a thoughtful approach.</p><div className="values-list"><span>Clarity</span><span>Credibility</span><span>Care</span><span>Long-term value</span></div></div>
          <span className="values-orbit orbit-one" aria-hidden="true" /><span className="values-orbit orbit-two" aria-hidden="true" />
        </section>
        <section className="home-contact section-wrap"><div><span className="section-kicker">The next conversation</span><h2>Let’s find where<br /><em>we can help.</em></h2></div><p>Whether you’re growing a brand, looking for a property or building a team, start with the business that speaks to your need.</p><a className="button button-light" href="#businesses">Choose a business <ArrowRight size={16} /></a></section>
      </main>
      <Footer />
    </div>
  );
}
