import { useEffect, useState, type FormEvent } from "react";
import type { CSSProperties } from "react";
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, Menu, X } from "lucide-react";
import { Link } from "wouter";
import BrandLogo from "../components/BrandLogo";
import { businessBySlug, businesses } from "../data/businesses";

function BusinessHeader({ active }: { active: string }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <header className="site-header business-header">
      <div className="header-inner">
        <Link href="/" className="home-brand" aria-label="Global India Group home"><BrandLogo compact /></Link>
        <button className="menu-toggle" aria-label={menuOpen ? "Close navigation" : "Open navigation"} aria-expanded={menuOpen} onClick={() => setMenuOpen((value) => !value)}>{menuOpen ? <X size={21} /> : <Menu size={21} />}</button>
        <nav className={`main-nav ${menuOpen ? "nav-open" : ""}`} aria-label="Main navigation">
          <Link href="/" className="nav-link">The group</Link>
          {businesses.map((business) => <Link key={business.slug} href={`/${business.slug}`} className={`nav-link ${business.slug === active ? "nav-active" : ""}`} onClick={() => setMenuOpen(false)}>{business.shortName}</Link>)}
          <a href="#enquiry" className="nav-cta" onClick={() => setMenuOpen(false)}>Make an enquiry <ArrowUpRight size={15} /></a>
        </nav>
      </div>
    </header>
  );
}

function SiteFooter() {
  return <footer className="site-footer"><div className="footer-main"><BrandLogo inverse compact /><p>Three specialist teams, connected by a bigger picture.</p><Link href="/">← Back to Global India Group</Link></div><div className="footer-bottom"><span>© {new Date().getFullYear()} Global India Group</span><span>Distinct expertise. Shared purpose.</span></div></footer>;
}

function EnquiryForm({ slug, name, email, services }: { slug: string; name: string; email?: string; services: { title: string }[] }) {
  const [submitted, setSubmitted] = useState(false);
  const [copied, setCopied] = useState(false);
  const [copyFailed, setCopyFailed] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const contactName = String(form.get("name") ?? "");
    const contactEmail = String(form.get("email") ?? "");
    const phone = String(form.get("phone") ?? "");
    const interest = String(form.get("interest") ?? "");
    const message = String(form.get("message") ?? "");
    const subject = `Enquiry for ${name} — ${interest}`;
    const body = [`Name: ${contactName}`, `Email: ${contactEmail}`, phone ? `Phone: ${phone}` : "", `Area of interest: ${interest}`, "", message].filter(Boolean).join("\n");

    if (email) {
      window.location.href = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
      setSubmitted(true);
      return;
    }

    try {
      await navigator.clipboard.writeText(`${subject}\n\n${body}`);
      setCopied(true);
    } catch {
      setCopyFailed(true);
    }
    setSubmitted(true);
  }

  return (
    <div className="enquiry-layout">
      <div className="enquiry-copy"><span className="section-kicker">Start a conversation</span><h2>Tell us what<br /><em>you have in mind.</em></h2><p>Share a little about your needs and the right team can take the conversation forward.</p>{email ? <a className="contact-email" href={`mailto:${email}`}>{email} <ArrowUpRight size={15} /></a> : <a className="contact-email" href="https://globalindianagpur.com" target="_blank" rel="noreferrer">Visit Global India Group <ArrowUpRight size={15} /></a>}</div>
      <div className="form-card">
        {submitted ? (
          <div className="form-success" role="status"><span className="success-icon"><Check size={22} /></span><span className="section-kicker">Enquiry prepared</span><h3>{email ? "Your email app is ready." : "Your message is ready."}</h3><p>{email ? `A draft addressed to ${email} has been prepared. Please review it and press Send in your email app.` : copied ? "Your enquiry details have been copied. Use the Global India Group website to send your message." : copyFailed ? "Your browser could not copy the message. Please contact Global India Group through its website and include your enquiry details." : "Please contact Global India Group through its website to send your enquiry."}</p>{email ? <a href={`mailto:${email}`} className="text-link">Email {email} <ArrowRight size={15} /></a> : <a className="text-link" href="https://globalindianagpur.com" target="_blank" rel="noreferrer">Open Global India Group <ArrowUpRight size={15} /></a>}<button className="reset-form" onClick={() => { setSubmitted(false); setCopied(false); setCopyFailed(false); }}>Prepare another enquiry</button></div>
        ) : (
          <form className="enquiry-form" onSubmit={handleSubmit}>
            <div className="form-row"><label>Full name <input name="name" type="text" autoComplete="name" placeholder="Your name" required /></label><label>Email address <input name="email" type="email" autoComplete="email" placeholder="you@example.com" required /></label></div>
            <div className="form-row"><label>Phone <span className="optional">Optional</span><input name="phone" type="tel" autoComplete="tel" placeholder="+91" /></label><label>I'm interested in<select name="interest" defaultValue="" required><option value="" disabled>Select an area</option>{services.map((service) => <option key={service.title}>{service.title}</option>)}</select></label></div>
            <label>Your message<textarea name="message" rows={4} placeholder="A few details will help us understand what you need…" required /></label>
            <button className="button button-dark form-submit" type="submit">Prepare my enquiry <ArrowRight size={16} /></button>
            <p className="form-privacy">Your enquiry is prepared in your email app. No information is saved on this website.</p>
          </form>
        )}
      </div>
    </div>
  );
}

export default function BusinessPage({ slug }: { slug: string }) {
  const business = businessBySlug(slug);
  useEffect(() => {
    if (business) document.title = `${business.name} | Global India Group`;
  }, [business]);
  if (!business) return null;

  const style = { "--brand": business.brand, "--brand-soft": business.soft, "--brand-ink": business.ink } as CSSProperties;

  return (
    <div className={`site-shell business-page business-${business.slug}`} style={style}>
      <BusinessHeader active={business.slug} />
      <main>
        <section className="business-hero section-wrap">
          <div className="business-hero-copy">
            <Link href="/" className="back-link"><ArrowLeft size={14} /> Global India Group</Link>
            <BrandLogo kind={business.logo} className="business-hero-logo" />
            <div className="business-descriptor hero-descriptor">{business.descriptor}</div>
            <p className="business-tagline">{business.tagline}</p>
            <h1>{business.heroTitle}<br /><em>{business.tagline === "Building Dreams. Creating Homes." ? "Build from here." : business.slug === "media" ? "Reach the right people." : "Find your next step."}</em></h1>
            <p className="business-hero-intro">{business.heroCopy}</p>
            <div className="business-hero-actions"><a className="button button-brand" href="#enquiry">Talk to our team <ArrowRight size={16} /></a><a className="secondary-link" href="#services">Explore services <span>↓</span></a></div>
          </div>
          <div className="business-hero-image"><img src={business.heroImage} alt={business.heroAlt} /><span className="image-index">{business.shortName} <i>—</i> 01</span><div className="image-quote">{business.slug === "media" ? "Your story deserves a wider audience." : business.slug === "properties" ? "A foundation for what comes next." : "Connecting potential with possibility."}</div></div>
          <div className="hero-vertical-label">{business.name.toUpperCase()}</div>
        </section>

        <section className="business-intro section-wrap"><div className="section-kicker">A thoughtful approach</div><div className="business-intro-main"><h2>{business.slug === "media" ? <>From visibility<br />to <em>credibility.</em></> : business.slug === "properties" ? <>More than a property.<br /><em>A future taking shape.</em></> : <>A stronger connection<br />between <em>people and work.</em></>}</h2><div><p>{business.intro}</p><p>{business.audience}</p></div></div>{business.disclaimer ? <p className="business-disclaimer"><strong>Important note</strong>{business.disclaimer}</p> : null}</section>

        <section className="services-section section-wrap" id="services"><div className="services-heading"><div><span className="section-kicker">What we do</span><h2>Practical expertise.<br /><em>Personal attention.</em></h2></div><p>{business.slug === "media" ? "A connected set of capabilities for brands that want to communicate with clarity." : business.slug === "properties" ? "Guidance through the decisions that shape where you live, work and invest." : "Support for candidates and employers at every stage of the employment journey."}</p></div><div className="service-list">{business.services.map((service, index) => <article className="service-item" key={service.title}><span className="service-number">{String(index + 1).padStart(2, "0")}</span><div><h3>{service.title}</h3><p>{service.copy}</p></div><span className="service-index-mark">↗</span></article>)}</div></section>

        <section className="gallery-section section-wrap"><div className="gallery-heading"><div><span className="section-kicker">The work, in context</span><h2>Built around <em>real life.</em></h2></div><span className="gallery-count">A closer look <span>02—03</span></span></div><div className="gallery-grid">{business.gallery.map((image, index) => <figure className={`gallery-frame gallery-frame-${index + 1}`} key={image.image}><img src={image.image} alt={image.alt} loading="lazy" /><figcaption><span>0{index + 2}</span>{image.caption}</figcaption></figure>)}</div></section>

        <section id="enquiry" className="enquiry-section section-wrap"><EnquiryForm slug={business.slug} name={business.name} email={business.email} services={business.services} /></section>
        <section className="other-businesses section-wrap"><span className="section-kicker">Part of something broader</span><p>Discover the other specialist businesses in the group.</p><div className="other-business-links">{businesses.filter((item) => item.slug !== business.slug).map((item) => <Link to={`/${item.slug}`} key={item.slug}><BrandLogo kind={item.logo} compact /><ArrowUpRight size={16} /></Link>)}</div></section>
      </main>
      <SiteFooter />
    </div>
  );
}
