export type Business = {
  slug: string;
  name: string;
  shortName: string;
  descriptor: string;
  tagline: string;
  intro: string;
  heroTitle: string;
  heroCopy: string;
  brand: string;
  soft: string;
  ink: string;
  logo: "media" | "property" | "workforce";
  heroImage: string;
  heroAlt: string;
  gallery: { image: string; alt: string; caption: string }[];
  services: { title: string; copy: string }[];
  email?: string;
  audience: string;
  formPrompt: string;
  disclaimer?: string;
};

export const businesses: Business[] = [
  {
    slug: "media",
    name: "Global India Media Services",
    shortName: "Media Services",
    descriptor: "Media · Digital · PR · Content · Events",
    tagline: "Connecting Brands, People & Ideas with India and the World",
    intro:
      "An integrated media and communication partner helping businesses, professionals and institutions build visibility, credibility and meaningful connections.",
    heroTitle: "Make your story matter.",
    heroCopy:
      "From a first announcement to a wider reputation, we bring media, content and communication together around your next move.",
    brand: "#38516b",
    soft: "#eaf0f3",
    ink: "#202d3a",
    logo: "media",
    heroImage: "/manus-storage/async-images/vZ88wgWRYaveG6BlUrjwiV/image-1.webp",
    heroAlt: "An Indian founder in conversation during a studio interview",
    gallery: [
      {
        image: "/manus-storage/async-images/vZ88wgWRYaveG6BlUrjwiV/image-2.webp",
        alt: "A journalist and entrepreneur developing a story together",
        caption: "Ideas shaped into stories",
      },
      {
        image: "/manus-storage/async-images/vZ88wgWRYaveG6BlUrjwiV/image-3.webp",
        alt: "A business leadership summit being filmed by a camera operator",
        caption: "Moments that reach further",
      },
    ],
    services: [
      { title: "Media publicity & PR", copy: "Business and product publicity, press releases, media coverage, campaign planning and reputation-building communication." },
      { title: "Digital media & growth", copy: "Social media management, website content, digital marketing, search visibility, online campaigns and reputation support." },
      { title: "Publications & profiles", copy: "Corporate profiles, industry articles, entrepreneur stories, sponsored features and magazine advertising." },
      { title: "Podcasts & interviews", copy: "Leadership conversations, expert interviews and video or audio podcast production." },
      { title: "Video & creative", copy: "Corporate, promotional and short-form video, reels, interviews, event coverage, photography, editing and graphic design." },
      { title: "Events & campaigns", copy: "Conferences, seminars, awards, launches and exhibitions with media coverage, advertising and live digital reporting." },
      { title: "Corporate branding", copy: "Company profiles, presentations, brochures, catalogues, logo identity and cohesive communication materials." },
      { title: "Special media projects", copy: "Editorial series, entrepreneur stories, industry reports and business award programmes." },
    ],
    audience: "For businesses, institutions, entrepreneurs and professionals ready to be seen clearly.",
    formPrompt: "Tell us what you want your next audience to know.",
  },
  {
    slug: "properties",
    name: "Gagaar Properties",
    shortName: "Properties",
    descriptor: "Development · Property Solutions · Investment",
    tagline: "Building Dreams. Creating Homes.",
    intro:
      "A professionally managed real-estate enterprise focused on reliable guidance, transparent dealings and spaces designed for long-term value.",
    heroTitle: "A better place to begin.",
    heroCopy:
      "Find the right space for the way you live, work or invest—with thoughtful options and support at every step.",
    brand: "#466b5a",
    soft: "#edf2e9",
    ink: "#24392f",
    logo: "property",
    heroImage: "/manus-storage/async-images/vZ88wgWRYaveG6BlUrjwiV/image-4.webp",
    heroAlt: "Contemporary residence framed by landscaped gardens in warm afternoon light",
    gallery: [
      {
        image: "/manus-storage/async-images/vZ88wgWRYaveG6BlUrjwiV/image-5.webp",
        alt: "Bright contemporary apartment with a leafy balcony",
        caption: "Homes that feel considered",
      },
      {
        image: "/manus-storage/async-images/KvOASsHDXBhrl6CKLP31s3/image-1.webp",
        alt: "A modern commercial building in an Indian business district",
        caption: "Spaces for what's next",
      },
    ],
    services: [
      { title: "Residential properties", copy: "Apartments, premium projects, residential plots, villas and independent homes." },
      { title: "Commercial properties", copy: "Shops, offices, showrooms and investment-oriented commercial spaces." },
      { title: "Property development", copy: "Residential and mixed-use development, land projects and development partnerships." },
      { title: "Sales & marketing", copy: "Project marketing, buyer assistance, property presentation and site visits." },
      { title: "Investment advisory", copy: "Location-led options and guidance for residential and commercial property investment." },
      { title: "Consultation & transaction support", copy: "Property selection, documentation coordination and transaction guidance." },
      { title: "Resale & brokerage", copy: "Buying and selling support with owner–buyer coordination and negotiation assistance." },
    ],
    email: "gagaarproperties@gmail.com",
    audience: "For home seekers, owners, organisations and investors exploring their next move.",
    formPrompt: "Share the kind of property or guidance you're looking for.",
  },
  {
    slug: "workforce",
    name: "India Workforce Solutions",
    shortName: "Workforce Solutions",
    descriptor: "Careers · Recruitment · Workforce Support",
    tagline: "Connecting Aspirants with Opportunities • Building Careers • Supporting Employers",
    intro:
      "A professional employment-support initiative connecting job aspirants with suitable opportunities and helping employers find capable, motivated candidates.",
    heroTitle: "The right connection changes everything.",
    heroCopy:
      "A clearer employment journey for candidates. A more focused connection to talent for organisations.",
    brand: "#376a77",
    soft: "#e8f1f0",
    ink: "#203b42",
    logo: "workforce",
    heroImage: "/manus-storage/async-images/KvOASsHDXBhrl6CKLP31s3/image-2.webp",
    heroAlt: "A candidate and recruiter having a focused conversation in a modern office",
    gallery: [
      {
        image: "/manus-storage/async-images/KvOASsHDXBhrl6CKLP31s3/image-3.webp",
        alt: "An Indian candidate meeting with an interviewer in a bright room",
        caption: "Confidence for the conversation",
      },
      {
        image: "/manus-storage/async-images/KvOASsHDXBhrl6CKLP31s3/image-4.webp",
        alt: "Graduates learning practical workplace skills with a mentor",
        caption: "Skills that open doors",
      },
    ],
    services: [
      { title: "Job placement assistance", copy: "Connect registered candidates with relevant opportunities based on their profile." },
      { title: "Candidate registration", copy: "A structured starting point for aspirants exploring employment opportunities." },
      { title: "Recruitment support", copy: "Candidate sourcing, preliminary screening and workforce coordination for employers." },
      { title: "Career guidance", copy: "General guidance on roles, eligibility, career options and professional development." },
      { title: "Resume & profile support", copy: "Present qualifications, skills and experience clearly and professionally." },
      { title: "Interview preparation", copy: "Practical preparation guidance to help candidates approach interviews with confidence." },
      { title: "Fresher & experienced support", copy: "Employment connections for new graduates, skilled workers and experienced professionals." },
      { title: "Workforce solutions", copy: "Candidate sourcing and coordination shaped around an organisation's workforce needs." },
    ],
    email: "indiaworkforce1@gmail.com",
    audience: "For job aspirants at every career stage—and employers seeking suitable candidates.",
    formPrompt: "Let us know if you're exploring a role or hiring for one.",
    disclaimer: "India Workforce Solutions facilitates employment-related support and connections between candidates and prospective employers. Job selection and employment are subject to the eligibility criteria, recruitment process and final decision of the respective employer.",
  },
];

export const businessBySlug = (slug: string) => businesses.find((business) => business.slug === slug);
