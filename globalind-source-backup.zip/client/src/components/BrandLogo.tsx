import type { CSSProperties } from "react";

type MarkKind = "group" | "media" | "property" | "workforce";

type BrandLogoProps = {
  kind?: MarkKind;
  compact?: boolean;
  inverse?: boolean;
  className?: string;
};

function Mark({ kind }: { kind: MarkKind }) {
  if (kind === "media") {
    return (
      <svg viewBox="0 0 48 48" aria-hidden="true" className="brand-mark-svg">
        <circle cx="24" cy="24" r="18" fill="none" stroke="currentColor" strokeWidth="1.5" />
        <circle cx="24" cy="24" r="7" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="M24 3v9M24 36v9M3 24h9M36 24h9M9.2 9.2l6.4 6.4m16.8 16.8 6.4 6.4m0-29.6-6.4 6.4M15.6 32.4l-6.4 6.4" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <circle cx="24" cy="24" r="2.5" fill="currentColor" />
      </svg>
    );
  }
  if (kind === "property") {
    return (
      <svg viewBox="0 0 48 48" aria-hidden="true" className="brand-mark-svg">
        <path d="M5 22 24 7l19 15" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinejoin="round" />
        <path d="M11 20v21h26V20M19 41V27h10v14M15 24h4m10 0h4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
        <path d="M21 13V7h6v11" fill="none" stroke="currentColor" strokeWidth="1.7" />
      </svg>
    );
  }
  if (kind === "workforce") {
    return (
      <svg viewBox="0 0 48 48" aria-hidden="true" className="brand-mark-svg">
        <circle cx="24" cy="11" r="5" fill="none" stroke="currentColor" strokeWidth="2" />
        <circle cx="10" cy="34" r="5" fill="none" stroke="currentColor" strokeWidth="2" />
        <circle cx="38" cy="34" r="5" fill="none" stroke="currentColor" strokeWidth="2" />
        <path d="m20.7 15.3-7.4 13.4m14-13.4 7.4 13.4M15 34h18" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
        <path d="M21 23h6m-3-3v6" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      </svg>
    );
  }
  return (
    <svg viewBox="0 0 48 48" aria-hidden="true" className="brand-mark-svg group-mark">
      <circle cx="24" cy="24" r="19" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <path d="M5 24h38M24 5c6 5.3 9 11.6 9 19s-3 13.7-9 19M24 5c-6 5.3-9 11.6-9 19s3 13.7 9 19" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="24" cy="24" r="3.4" fill="currentColor" />
      <circle cx="24" cy="7.5" r="2.1" fill="currentColor" />
      <circle cx="9.7" cy="32" r="2.1" fill="currentColor" />
      <circle cx="38.3" cy="32" r="2.1" fill="currentColor" />
    </svg>
  );
}

export default function BrandLogo({ kind = "group", compact = false, inverse = false, className = "" }: BrandLogoProps) {
  const label = kind === "group" ? "Global India Group" : kind === "media" ? "Global India Media Services" : kind === "property" ? "Gagaar Properties" : "India Workforce Solutions";
  const style = kind === "group" ? undefined : ({ "--brand": kind === "media" ? "#38516b" : kind === "property" ? "#466b5a" : "#376a77" } as CSSProperties);
  return (
    <span className={`brand-lockup ${compact ? "brand-lockup-compact" : ""} ${inverse ? "brand-lockup-inverse" : ""} ${className}`} style={style} aria-label={label}>
      <span className="brand-symbol"><Mark kind={kind} /></span>
      <span className="brand-wordmark">
        {kind === "group" ? <><strong>GLOBAL INDIA</strong><span>GROUP · NAGPUR</span></> : kind === "media" ? <><strong>GLOBAL INDIA</strong><span>MEDIA SERVICES</span></> : kind === "property" ? <><strong>GAGAAR</strong><span>PROPERTIES</span></> : <><strong>INDIA</strong><span>WORKFORCE SOLUTIONS</span></>}
      </span>
    </span>
  );
}
